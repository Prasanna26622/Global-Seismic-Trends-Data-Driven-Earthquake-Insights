
import streamlit as st
import sqlite3
import pandas as pd
import plotly.express as px

# ---------------- Page Settings ----------------
st.set_page_config(
    page_title="Global Seismic Trends Dashboard",
    page_icon="🌍",
    layout="wide"
)

# ---------------- Load Data ----------------
conn = sqlite3.connect("earthquake.db")
df = pd.read_sql("SELECT * FROM earthquakes", conn)
conn.close()

# Time convert
df["time"] = pd.to_datetime(df["time"], unit="ms", errors="coerce")

# Remove null values
df = df.dropna(subset=["latitude","longitude","magnitude","depth","time"])

# Country extraction
df["country"] = df["place"].apply(
    lambda x: x.split(",")[-1].strip() if "," in x else x
)

# Magnitude Category
def category(m):
    if m < 3:
        return "Minor"
    elif m < 5:
        return "Light"
    elif m < 7:
        return "Strong"
    else:
        return "Major"

df["category"] = df["magnitude"].apply(category)

# Negative magnitude fix for map size
df["marker_size"] = df["magnitude"].clip(lower=0) + 1

# ---------------- Sidebar ----------------
st.sidebar.header("Dashboard Filters")

min_mag = float(df["magnitude"].min())
max_mag = float(df["magnitude"].max())

selected = st.sidebar.slider(
    "Magnitude Range",
    min_mag,
    max_mag,
    (min_mag, max_mag)
)

df = df[
    (df["magnitude"] >= selected[0]) &
    (df["magnitude"] <= selected[1])
]

# ---------------- Title ----------------
st.title("🌍 Global Seismic Trends Dashboard")
st.caption("Data Source: USGS Earthquake API")

# ---------------- KPI Cards ----------------
c1,c2,c3 = st.columns(3)

c1.metric("Total Earthquakes", len(df))
c2.metric("Highest Magnitude", round(df["magnitude"].max(),2))
c3.metric("Average Depth (km)", round(df["depth"].mean(),2))

st.divider()

# =========================================================
# Chart 1 - World Map
# =========================================================

st.subheader("1️⃣ Earthquake Locations")

fig_map = px.scatter_geo(
    df,
    lat="latitude",
    lon="longitude",
    color="magnitude",
    size="marker_size",
    hover_name="place",
    projection="natural earth",
    color_continuous_scale="Turbo"
)

fig_map.update_layout(height=600)

st.plotly_chart(fig_map, use_container_width=True)

st.divider()

# =========================================================
# Chart 2 - Monthly Trend
# =========================================================

st.subheader("2️⃣ Monthly Earthquake Trend")

monthly = (
    df.groupby(df["time"].dt.to_period("M"))
      .size()
      .reset_index(name="Count")
)

monthly["time"] = monthly["time"].astype(str)

fig_line = px.line(
    monthly,
    x="time",
    y="Count",
    markers=True
)

fig_line.update_layout(height=400)

st.plotly_chart(fig_line, use_container_width=True)

st.divider()

# =========================================================
# Chart 3 & 4
# =========================================================

left,right = st.columns(2)

with left:

    st.subheader("3️⃣ Top 10 Countries")

    top = (
        df["country"]
        .value_counts()
        .head(10)
        .reset_index()
    )

    top.columns=["Country","Count"]

    fig_bar = px.bar(
        top,
        x="Country",
        y="Count",
        color="Count",
        color_continuous_scale="Viridis"
    )

    fig_bar.update_layout(height=420)

    st.plotly_chart(fig_bar, use_container_width=True)

with right:

    st.subheader("4️⃣ Magnitude Categories")

    pie = (
        df["category"]
        .value_counts()
        .reset_index()
    )

    pie.columns=["Category","Count"]

    fig_pie = px.pie(
        pie,
        names="Category",
        values="Count",
        hole=0.4
    )

    fig_pie.update_layout(height=420)

    st.plotly_chart(fig_pie, use_container_width=True)

st.divider()

# =========================================================
# Chart 5
# =========================================================

st.subheader("5️⃣ Depth vs Magnitude")

fig_scatter = px.scatter(
    df,
    x="depth",
    y="magnitude",
    color="category",
    hover_name="place"
)

fig_scatter.update_layout(height=500)

st.plotly_chart(fig_scatter, use_container_width=True)

st.divider()

# =========================================================
# Chart 6
# =========================================================

st.subheader("6️⃣ Magnitude Distribution")

fig_hist = px.histogram(
    df,
    x="magnitude",
    color="category",
    nbins=20
)

fig_hist.update_layout(height=450)

st.plotly_chart(fig_hist, use_container_width=True)

st.divider()

# ---------------- Data Table ----------------

st.subheader("📋 Earthquake Data")

st.dataframe(
    df[["place","country","magnitude","depth","time"]],
    use_container_width=True
)