
import sqlite3
import pandas as pd

# CSV read
df = pd.read_csv("earthquake.csv")

# SQLite database create
conn = sqlite3.connect("earthquake.db")

# Table create & data insert
df.to_sql("earthquakes", conn, if_exists="replace", index=False)

conn.close()

print("Database Created Successfully!")