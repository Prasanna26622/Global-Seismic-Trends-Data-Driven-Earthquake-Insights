
import requests
import pandas as pd

url = "https://earthquake.usgs.gov/fdsnws/event/1/query"

params = {
    "format": "geojson",
    "starttime": "2026-01-01",
    "endtime": "2026-09-13",
    "limit": 1000
}

headers = {"User-Agent": "Mozilla/5.0"}

response = requests.get(url, params=params, headers=headers)

print("Status Code:", response.status_code)

if response.status_code == 200:
    data = response.json()

    rows = []
    for i in data["features"]:
        p = i["properties"]
        c = i["geometry"]["coordinates"]

        rows.append({
            "place": p["place"],
            "magnitude": p["mag"],
            "time": p["time"],
            "longitude": c[0],
            "latitude": c[1],
            "depth": c[2]
        })

    df = pd.DataFrame(rows)
    df.to_csv("earthquake.csv", index=False)

    print("Data Saved Successfully!")
else:
    print("API Error:", response.text)